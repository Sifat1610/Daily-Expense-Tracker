document.addEventListener("DOMContentLoaded", () => {
    const startBalanceInput = document.getElementById("start-balance");
    const newIncomeInput = document.getElementById("new-income");
    const totalBalanceDisplay = document.getElementById("total-balance");
    const descriptionInput = document.getElementById("description");
    const expenseAmountInput = document.getElementById("expense-amount");
    const totalExpenseDisplay = document.getElementById("total-expense");
    const remainingBalanceDisplay = document.getElementById("remaining-balance");
    const dailyIncomeDisplay = document.getElementById("daily-income");  // New element for displaying today's income
    const historyTableBody = document.getElementById("history-table").querySelector("tbody");
    const dateDisplay = document.getElementById("date-time");
    
    let totalBalance = 0;
    let totalExpense = 0;
    let totalIncome = 0;  // New variable to track total income
    let isStartBalanceSet = false; // Track if Starting Balance is already set
    let expenseHistory = []; // To keep track of all expenses

    // Update date and time
    const updateDateTime = () => {
        const now = new Date();
        dateDisplay.textContent = `Date: ${now.toLocaleDateString()} | Time: ${now.toLocaleTimeString()}`;
    };
    setInterval(updateDateTime, 1000);

    // Clear input fields (excluding Starting Balance)
    const clearInputs = () => {
        newIncomeInput.value = '';
        descriptionInput.value = '';
        expenseAmountInput.value = '';
    };

    // Set or Update Starting Balance
    document.getElementById("update-balance").addEventListener("click", () => {
        const startBalance = parseFloat(startBalanceInput.value) || 0;
        const newIncome = parseFloat(newIncomeInput.value) || 0;

        if (!isStartBalanceSet) {
            // If Starting Balance is not yet set
            totalBalance = startBalance;
            isStartBalanceSet = true; // Lock Starting Balance
        }

        if (newIncome > 0) {
            // Add New Income to Total Balance
            totalIncome += newIncome; // Track new income
            totalBalance += newIncome; // Update the total balance
            newIncomeInput.value = ''; // Clear New Income input
        }

        // Update the displays
        totalBalanceDisplay.textContent = totalBalance.toFixed(2);
        remainingBalanceDisplay.textContent = totalBalance.toFixed(2);
        dailyIncomeDisplay.textContent = totalIncome.toFixed(2); // Show today's income
    });

    // Add expense
    document.getElementById("add-expense").addEventListener("click", () => {
        const description = descriptionInput.value;
        const expenseAmount = parseFloat(expenseAmountInput.value) || 0;

        if (description && expenseAmount) {
            totalExpense += expenseAmount;
            totalBalance -= expenseAmount;

            totalExpenseDisplay.textContent = totalExpense.toFixed(2);
            totalBalanceDisplay.textContent = totalBalance.toFixed(2);
            remainingBalanceDisplay.textContent = totalBalance.toFixed(2);

            const now = new Date();
            const date = now.toLocaleDateString('en-GB'); // dd/mm/yyyy format
            const expense = { date, description, amount: expenseAmount };

            // Add to history array
            expenseHistory.push(expense);

            const row = `<tr>
                <td>${date}</td>
                <td>${description}</td>
                <td>${expenseAmount.toFixed(2)}</td>
            </tr>`;
            historyTableBody.insertAdjacentHTML("beforeend", row);

            // Clear the expense input fields
            clearInputs();
        }
    });

    // Search expenses by date (dd/mm/yyyy format)
    searchBtn.addEventListener("click", () => {
        const searchDate = searchDateInput.value.trim();
        if (searchDate) {
            const [day, month, year] = searchDate.split('/');
            const formattedDate = `${day.padStart(2, '0')}/${month.padStart(2, '0')}/${year}`;

            // Filter history based on the search date
            const filteredHistory = expenseHistory.filter(expense => expense.date === formattedDate);

            // Clear the table body
            historyTableBody.innerHTML = '';

            // Display filtered results
            filteredHistory.forEach(expense => {
                const row = `<tr>
                    <td>${expense.date}</td>
                    <td>${expense.description}</td>
                    <td>${expense.amount.toFixed(2)}</td>
                </tr>`;
                historyTableBody.insertAdjacentHTML("beforeend", row);
            });
        }
    });
});
